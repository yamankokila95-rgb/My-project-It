import Database from "better-sqlite3";
import bcrypt from "bcryptjs";

const db = new Database("backend/mindcare.db");
db.pragma("journal_mode = WAL");

// Users table
db.prepare(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`).run();

// Check-ins table — full data from CheckInForm
db.prepare(`
  CREATE TABLE IF NOT EXISTS checkins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER NOT NULL,
    mood TEXT NOT NULL,
    stressLevel TEXT NOT NULL,
    hoursSlept REAL NOT NULL,
    studyHours REAL NOT NULL,
    notes TEXT DEFAULT '',
    date TEXT NOT NULL,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id),
    UNIQUE(userId, date)
  )
`).run();

console.log("✅ MindCare database ready");
export default db;
