export const API_BASE = "";

export const getToken = () => localStorage.getItem("mindcareToken");

export const authFetch = async (path: string, options: RequestInit = {}) => {
  return fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
      ...(options.headers ?? {}),
    },
  });
};
