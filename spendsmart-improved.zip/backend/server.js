
import express from "express";
import cors from "cors";
import db from "./db.js";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/expenses", (req,res)=>{
  const data = db.prepare("SELECT * FROM expenses").all();
  res.json(data);
});

app.post("/expenses", (req,res)=>{
  const {title, amount} = req.body;
  const result = db.prepare(
    "INSERT INTO expenses (title,amount) VALUES (?,?)"
  ).run(title, amount);

  res.json({id: result.lastInsertRowid});
});

app.listen(3001, ()=>{
  console.log("Backend running on 3001");
});
