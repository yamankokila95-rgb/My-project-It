
import { useState } from "react";

export default function AddExpense() {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  const submit = async () => {
    await fetch("http://localhost:3001/expenses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, amount })
    });
    alert("Expense added");
  };

  return (
    <div style={{padding:40}}>
      <h1>Add Expense</h1>
      <input placeholder="Title" onChange={e=>setTitle(e.target.value)} />
      <input placeholder="Amount" onChange={e=>setAmount(e.target.value)} />
      <button onClick={submit}>Save</button>
    </div>
  );
}
