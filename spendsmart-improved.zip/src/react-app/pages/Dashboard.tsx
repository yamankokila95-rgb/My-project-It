
import { useEffect, useState } from "react";

export default function Dashboard() {
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3001/expenses")
      .then(res => res.json())
      .then(data => setExpenses(data));
  }, []);

  return (
    <div style={{padding:40}}>
      <h1>SpendSmart Dashboard</h1>
      <ul>
        {expenses.map((e:any) => (
          <li key={e.id}>
            {e.title} - ₹{e.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}
