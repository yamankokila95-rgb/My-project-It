
export default function Reports() {
  return (
    <div style={{padding:40}}>
      <h1>Reports</h1>
      <p>Analytics will appear here.</p>
    </div>
  );
}
