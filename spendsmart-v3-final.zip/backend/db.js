
import Database from "better-sqlite3"

const db=new Database("database.db")

db.prepare(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT,
 password TEXT
)
`).run()

db.prepare(`
CREATE TABLE IF NOT EXISTS expenses(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT,
 amount REAL
)
`).run()

export default db
