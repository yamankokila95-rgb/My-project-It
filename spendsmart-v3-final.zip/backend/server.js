
import express from "express"
import cors from "cors"
import jwt from "jsonwebtoken"
import db from "./db.js"

const app=express()
app.use(cors())
app.use(express.json())

const SECRET="spendsmart_secret"

app.post("/register",(req,res)=>{
 const {email,password}=req.body
 db.prepare("INSERT INTO users(email,password) VALUES(?,?)").run(email,password)
 res.json({message:"user created"})
})

app.post("/login",(req,res)=>{
 const {email,password}=req.body
 const user=db.prepare(
  "SELECT * FROM users WHERE email=? AND password=?"
 ).get(email,password)

 if(!user) return res.status(401).json({error:"invalid credentials"})

 const token=jwt.sign({id:user.id},SECRET)
 res.json({token})
})

app.get("/expenses",(req,res)=>{
 res.json(db.prepare("SELECT * FROM expenses").all())
})

app.post("/expenses",(req,res)=>{
 const {title,amount}=req.body
 db.prepare("INSERT INTO expenses(title,amount) VALUES(?,?)").run(title,amount)
 res.json({message:"saved"})
})

app.listen(3001,()=>{
 console.log("Backend running on 3001")
})
