
import {BrowserRouter,Routes,Route} from "react-router-dom"
import Dashboard from "./pages/Dashboard"
import Login from "./pages/Login"
import Register from "./pages/Register"
import AddExpense from "./pages/AddExpense"
import Reports from "./pages/Reports"
import Sidebar from "./components/Sidebar"

export default function App(){
 return(
  <BrowserRouter>
   <div className="flex">
     <Sidebar/>
     <div className="flex-1 p-6">
       <Routes>
         <Route path="/" element={<Dashboard/>}/>
         <Route path="/login" element={<Login/>}/>
         <Route path="/register" element={<Register/>}/>
         <Route path="/add" element={<AddExpense/>}/>
         <Route path="/reports" element={<Reports/>}/>
       </Routes>
     </div>
   </div>
  </BrowserRouter>
 )
}
