
import {Link} from "react-router-dom"

export default function Sidebar(){
 return(
  <div className="w-64 h-screen bg-blue-600 text-white p-6">
    <h2 className="text-2xl font-bold mb-6">SpendSmart</h2>
    <nav className="space-y-3">
      <Link to="/">Dashboard</Link><br/>
      <Link to="/add">Add Expense</Link><br/>
      <Link to="/reports">Reports</Link><br/>
      <Link to="/login">Login</Link>
    </nav>
  </div>
 )
}
