
import {useEffect,useState} from "react"
import StatCard from "../components/StatCard"

export default function Dashboard(){

 const [expenses,setExpenses]=useState<any[]>([])

 useEffect(()=>{
  fetch("http://localhost:3001/expenses")
  .then(res=>res.json())
  .then(setExpenses)
 },[])

 const total=expenses.reduce((s,e)=>s+Number(e.amount),0)

 return(
  <div>
   <h1 className="text-2xl font-bold mb-4">Dashboard</h1>

   <div className="grid grid-cols-3 gap-4 mb-6">
     <StatCard title="Total Expenses" value={"₹"+total}/>
     <StatCard title="Transactions" value={expenses.length}/>
     <StatCard title="Budget" value="₹20000"/>
   </div>

   <div className="bg-white p-4 shadow rounded">
     <h2 className="font-bold mb-2">Recent Expenses</h2>
     {expenses.map(e=>(
       <div key={e.id} className="border-b py-2">
         {e.title} - ₹{e.amount}
       </div>
     ))}
   </div>
  </div>
 )
}
