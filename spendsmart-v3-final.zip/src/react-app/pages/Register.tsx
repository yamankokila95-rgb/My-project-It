
import {useState} from "react"

export default function Register(){

 const [email,setEmail]=useState("")
 const [password,setPassword]=useState("")

 const register=async()=>{
   await fetch("http://localhost:3001/register",{
     method:"POST",
     headers:{"Content-Type":"application/json"},
     body:JSON.stringify({email,password})
   })
   alert("User created")
 }

 return(
  <div className="max-w-sm mx-auto bg-white p-6 shadow rounded">
   <h2 className="text-xl font-bold mb-4">Register</h2>
   <input className="border p-2 w-full mb-2"
    placeholder="Email"
    onChange={e=>setEmail(e.target.value)}/>
   <input className="border p-2 w-full mb-4"
    type="password"
    placeholder="Password"
    onChange={e=>setPassword(e.target.value)}/>
   <button className="bg-green-600 text-white w-full py-2"
    onClick={register}>
    Create Account
   </button>
  </div>
 )
}
