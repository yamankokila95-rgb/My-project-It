
import express from "express"
import cors from "cors"
import db from "./db.js"

const app = express()
app.use(cors())
app.use(express.json())

app.get("/expenses",(req,res)=>{
 res.json(db.prepare("SELECT * FROM expenses").all())
})

app.post("/expenses",(req,res)=>{
 const {title,amount}=req.body
 const r=db.prepare(
   "INSERT INTO expenses(title,amount) VALUES(?,?)"
 ).run(title,amount)
 res.json({id:r.lastInsertRowid})
})

app.listen(3001,()=>{
 console.log("Backend running on 3001")
})
