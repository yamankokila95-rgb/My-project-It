
import {useState} from "react"

export default function AddExpense(){

 const [title,setTitle]=useState("")
 const [amount,setAmount]=useState("")

 const save=async()=>{
  await fetch("http://localhost:3001/expenses",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({title,amount})
  })
  alert("Expense saved")
 }

 return(
  <div>
   <h1 className="text-xl font-bold mb-4">Add Expense</h1>

   <input className="border p-2 mr-2"
    placeholder="Title"
    onChange={e=>setTitle(e.target.value)}/>

   <input className="border p-2 mr-2"
    placeholder="Amount"
    onChange={e=>setAmount(e.target.value)}/>

   <button className="bg-blue-600 text-white px-4 py-2"
    onClick={save}>
     Save
   </button>
  </div>
 )
}
