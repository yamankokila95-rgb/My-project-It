
export default function Register(){
 return(
  <div className="max-w-sm mx-auto bg-white p-6 shadow rounded">
   <h2 className="text-xl font-bold mb-4">Register</h2>
   <input className="border p-2 w-full mb-2" placeholder="Name"/>
   <input className="border p-2 w-full mb-2" placeholder="Email"/>
   <input className="border p-2 w-full mb-4" placeholder="Password" type="password"/>
   <button className="bg-green-600 text-white w-full py-2">Create Account</button>
  </div>
 )
}
