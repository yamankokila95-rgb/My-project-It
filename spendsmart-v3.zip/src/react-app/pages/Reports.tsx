
import {LineChart,Line,XAxis,YAxis,Tooltip,CartesianGrid} from "recharts"

const data=[
 {month:"Jan",amount:2000},
 {month:"Feb",amount:3500},
 {month:"Mar",amount:4200}
]

export default function Reports(){
 return(
  <div>
   <h1 className="text-xl font-bold mb-4">Spending Reports</h1>

   <LineChart width={600} height={300} data={data}>
     <XAxis dataKey="month"/>
     <YAxis/>
     <Tooltip/>
     <CartesianGrid stroke="#ccc"/>
     <Line dataKey="amount"/>
   </LineChart>
  </div>
 )
}
